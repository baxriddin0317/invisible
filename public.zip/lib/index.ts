export const menu = [
  {
    name: "Industries",
    links: [
      {
        name: "Page One",
        href: "/"
      },
      {
        name: "Page Two",
        href: "safety"
      },
      {
        name: "Page Three",
        href: "automotive"
      },
    ]
  },
  {
    name: "Solutions",
    links: [
      {
        name: "Page One",
        href: "/"
      },
      {
        name: "Page Two",
        href: "safety"
      },
      {
        name: "Page Three",
        href: "automotive"
      },
    ]
  },
  {
    name: " Company",
    links: [
      {
        name: "About",
        href: "about"
      },
    ]
  },
]