/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['www.geoguessr.com'],
  },
};

export default nextConfig;
